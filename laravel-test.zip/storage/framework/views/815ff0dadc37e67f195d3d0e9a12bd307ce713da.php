<style>
.padding{padding:20px;}
</style>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Панель</div>
								<div class="card uper">
								<div class="card-body padding">
									<?php if($errors->any()): ?>
										<div class="alert alert-danger">
											<ul>
													<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<li><?php echo e($error); ?></li>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</ul>
										</div><br />
									<?php endif; ?>
									<?php if(session()->has('message')): ?>
	    <div class="alert alert-success">
	        <?php echo e(session()->get('message')); ?>

	    </div>
	<?php endif; ?>
<? if($add_allowed!=0){ ?>
										<form method="post" action="<?php echo e(route('form.store')); ?>" enctype="multipart/form-data">
											<?php echo e(csrf_field()); ?>

												<div class="form-group">
														<label for="name">Тема сообщения:</label>
														<input type="text" class="form-control" name="subject"/>
												</div>
												<div class="form-group">
														<label for="price">Сообщение:</label>
														<textarea type="text" class="form-control" name="Message"/></textarea>
												</div>
												<div class="form-group">
														<label for="quantity">Файл:</label>
														<input type="file" class="form-control" name="file"/>
												</div>
												<button type="submit" class="btn btn-primary">Создать заявку</button>
										</form>
										<?}else{?>
											<div class="alert alert-danger">
											Вы уше подали заявку. Следующую можно подать только через 24 часа.
											</div>
											<?}?>
								</div>
								</div>

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>