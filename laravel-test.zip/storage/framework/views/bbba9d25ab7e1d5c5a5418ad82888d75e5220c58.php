<div class="well col-sm-8">
    <?php echo e($feedback); ?>

</div>
